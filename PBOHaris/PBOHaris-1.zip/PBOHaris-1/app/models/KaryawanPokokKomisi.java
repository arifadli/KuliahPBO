package models;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class KaryawanPokokKomisi extends KaryawanKomisi{
    private double PendapatanPokok;
    public void KaryawanPokokKomisi(double PendapatanPokok,double PendapatanKomisi){
        gaji=PendapatanPokok+PendapatanKomisi;
        this.PendapatanKomisi=PendapatanKomisi;
        this.PendapatanPokok=PendapatanPokok;
    }
    public void setPendapatanPokok(double PendapatanPokok){
        gaji=PendapatanPokok+PendapatanKomisi;
        this.PendapatanPokok=PendapatanPokok;
    }
    public void setPendapatanKomisi(double PendapatanKomisi){
        this.PendapatanKomisi=PendapatanKomisi;
        gaji=PendapatanKomisi+PendapatanPokok;
    }
}