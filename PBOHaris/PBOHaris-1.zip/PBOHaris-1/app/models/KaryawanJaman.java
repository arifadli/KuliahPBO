package models;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class KaryawanJaman extends Karyawan{
    private double PendapatanJaman=0;
    private double Jam=0;
    public void KaryawanJaman(double PendapatanJaman, double Jam){
        gaji=PendapatanJaman*Jam;
        this.Jam=Jam;
        this.PendapatanJaman=PendapatanJaman;
    }
    public void KaryawanJaman(){
        gaji=0;
    }
    public void setPendapatanJaman(double PendapatanJaman){
        this.PendapatanJaman=PendapatanJaman;
        gaji=PendapatanJaman*Jam;
    }
    public void setJam(double Jam){
        this.Jam=Jam;
        gaji=PendapatanJaman*Jam;
    }
}
