package models;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class Invoice extends Model implements Payable {
    public double JumlahPembayaran(){
        return quantity*pricePerItem;
    }
    private String partNumber;
    private String partDescription;
    private int quantity;
    private double pricePerItem;
    
}
