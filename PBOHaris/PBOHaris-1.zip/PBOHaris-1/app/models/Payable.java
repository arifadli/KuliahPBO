package models;

import javax.persistence.Entity;

import play.db.jpa.Model;


public interface Payable {
	public double JumlahPembayaran();

}