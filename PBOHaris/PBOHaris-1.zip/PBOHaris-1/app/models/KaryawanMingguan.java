package models;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class KaryawanMingguan extends Karyawan{
    private double PendapatanMingguan=0;
    public void KaryawanMingguan(double PendapatanMingguan){
        gaji=PendapatanMingguan;
    }
    public void KaryawanMingguan(){
        gaji=PendapatanMingguan;
    }
    public void setPendapatanMingguan(double PendapatanMingguan){
        this.PendapatanMingguan=PendapatanMingguan;
        gaji=PendapatanMingguan;
    }
}
