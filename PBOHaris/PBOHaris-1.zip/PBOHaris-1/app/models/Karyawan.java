package models;

import javax.persistence.Entity;

import play.db.jpa.Model;

@Entity
public class Karyawan extends Model implements Payable {
    public double JumlahPembayaran(){
        return gaji;
    }
	public String namadepan;
	public String namabelakang;
	public int noidentitas;
    public double gaji;
	public String toString(){
		return this.namadepan+" "+this.namabelakang;
	}
	

}