package models;

import javax.persistence.Entity;
import javax.validation.groups.Default;

import play.db.jpa.Model;

@Entity
public class KaryawanKomisi extends Karyawan {
    protected double PendapatanKomisi;
    public void KaryawanKomisi(double PendapatanKomisi){
        gaji=PendapatanKomisi;
    }
    public void KaryawanKomisi(){
        gaji=0;
    }
    public void setPendapatanKomisi(double PendapatanKomisi){
        this.PendapatanKomisi=PendapatanKomisi;
        gaji=PendapatanKomisi;
    }
    
}
