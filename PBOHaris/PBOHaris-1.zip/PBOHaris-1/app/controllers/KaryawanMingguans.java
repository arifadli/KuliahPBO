package controllers;
import play.*;
import play.mvc.*;

import java.util.*;

public class KaryawanMingguans extends CRUD {
    
}
