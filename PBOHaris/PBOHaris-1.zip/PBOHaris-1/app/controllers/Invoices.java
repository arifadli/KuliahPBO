package controllers;

public class Invoices extends CRUD {
    
}
