package controllers;
import play.*;
import play.mvc.*;

import java.util.*;

public class KaryawanKomisis extends CRUD{
    
}
