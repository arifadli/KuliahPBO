package controllers;
import play.*;
import play.mvc.*;

import java.util.*;


public class KaryawanJamans extends CRUD{
    private double gaji;
    //void KaryawangJamans(){
      //  gaji=models.KaryawanJaman.gaji;}
}
